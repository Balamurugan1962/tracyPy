# tracyPy
A lightweight Python library that wraps NumPy-style array operations but also retains an expression history
